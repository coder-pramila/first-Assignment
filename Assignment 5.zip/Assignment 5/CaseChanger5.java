public class Main {
  public static void main(String[] args) {
    String txt = "Hello i am pramila";
    System.out.println("To Upper case: "+ txt.toUpperCase());
      System.out.println("\t");
      System.out.println("\t");
    
    System.out.println( " " +"To lower case:"+ txt.toLowerCase());
      System.out.println("\t");
        String words[]=txt.split("\\s");
        String capitalizeStr="";
 
        for(String word:words){
            
            String firstLetter=word.substring(0,1);
            
            String remainingLetters=word.substring(1);
            capitalizeStr+=firstLetter.toUpperCase()+remainingLetters+" ";
        }
        System.out.println("Capitaliser : " +" "+  capitalizeStr);
         System.out.println("\t");
         System.out.println("Sentence case : " +" "+  txt);
        
    }
}
  
